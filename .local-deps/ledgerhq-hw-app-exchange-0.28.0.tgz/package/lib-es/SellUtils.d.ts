import { ledger_trade } from "./generate-protocol";
export type SellPayload = {
    deviceTransactionId: Uint8Array;
    inAddress: string;
    inAmount: Uint8Array;
    inCurrency: string;
    outAmount?: ledger_trade.IUDecimal | null;
    outCurrency: string;
    traderEmail: string;
    inExtraId?: string;
};
export declare function decodeSellPayload(payload: string): Promise<SellPayload>;
//# sourceMappingURL=SellUtils.d.ts.map