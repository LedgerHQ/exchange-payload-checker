import { secp256k1 } from "@noble/curves/secp256k1";
import { p256 } from "@noble/curves/nist";
import { sha256 } from "@noble/hashes/sha2";
import { base64UrlDecode } from "./shared-utils";
const CURVES = { secp256k1, secp256r1: p256 };
/** @ignore internal, runtime check for a curve coming from CAL or a JS caller. */
export const isSupportedPartnerCurve = (curve) => curve === "secp256k1" || curve === "secp256r1";
function curveOf(curve) {
    if (!isSupportedPartnerCurve(curve))
        throw new Error(`Unsupported curve: ${String(curve)}`);
    return CURVES[curve];
}
export function isValidSwapNgPartnerPublicKey(publicKey) {
    try {
        curveOf(publicKey.curve).Point.fromBytes(Uint8Array.from(publicKey.data));
        return true;
    }
    catch {
        return false;
    }
}
/**
 * @ignore internal, verifies a 64-byte compact r||s signature over SHA-256(message) like the
 * Exchange app, which accepts high-S signatures. Throws when r or s is 0 or not below the curve order,
 * or on an unsupported curve.
 */
export function verifyCompactSignature(publicKey, compactSignature, message) {
    return curveOf(publicKey.curve).verify(compactSignature, sha256(message), Uint8Array.from(publicKey.data), { prehash: false, lowS: false, format: "compact" });
}
/**
 * Classifies a Swap NG partner signature against the inputs a partner backend may have signed.
 * Never throws.
 *
 * @param payload base64url `NewTransactionResponse`, without its "." prefix
 * @param signature base64url of the 64-byte compact r||s signature
 */
export function classifySwapNgSignature(payload, signature, publicKey) {
    try {
        const compactSignature = base64UrlDecode(signature);
        if (compactSignature.length !== 64)
            return "signature_malformed";
        const verifies = (message) => verifyCompactSignature(publicKey, compactSignature, message);
        if (verifies(Buffer.from("." + payload))) {
            const rLeadingZero = compactSignature[0] === 0x00;
            const sLeadingZero = compactSignature[32] === 0x00;
            if (rLeadingZero && sLeadingZero)
                return "valid_leading_zero_rs";
            if (rLeadingZero)
                return "valid_leading_zero_r";
            if (sLeadingZero)
                return "valid_leading_zero_s";
            return "valid";
        }
        if (verifies(Buffer.from(payload)))
            return "signed_without_dot_prefix";
        if (verifies(base64UrlDecode(payload)))
            return "signed_raw_protobuf";
        return "invalid";
    }
    catch {
        return "signature_malformed";
    }
}
//# sourceMappingURL=SwapSignature.js.map