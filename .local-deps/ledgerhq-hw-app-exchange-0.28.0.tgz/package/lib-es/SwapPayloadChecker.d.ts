import { type SwapPayload } from "./SwapUtils";
import { type SwapNgPartnerPublicKey } from "./SwapSignature";
import { type PayloadCheckReport } from "./PayloadCheckerShared";
export type { SwapPayloadIssue, SwapPayloadIssueCode } from "./PayloadCheckerShared";
export type SwapPayloadCheckInput = {
    /**
     * "ng": base64url `NewTransactionResponse`, without the leading "." Ledger Live adds.
     * "legacy": hex of the raw protobuf `NewTransactionResponse`, without a "0x" prefix.
     */
    payload: string;
    /**
     * 64-byte compact r||s signature, base64url for "ng", 128 hex characters for "legacy".
     */
    signature: string;
    partnerPublicKey: SwapNgPartnerPublicKey;
    format?: "ng" | "legacy";
    /** values the payload must contain, only the provided keys are compared */
    expected?: {
        /**
         * nonce returned by `startNewTransaction`: 32-byte hex for "ng" (case-insensitive, optional
         * "0x"), 10 characters for "legacy"
         */
        deviceTransactionId?: string;
        currencyFrom?: string;
        currencyTo?: string;
        amountToProvider?: bigint;
        amountToWallet?: bigint;
        payinAddress?: string;
        payoutAddress?: string;
        refundAddress?: string;
    };
};
/**
 * A decoded `NewTransactionResponse` as reported by `checkSwapPayload`.
 */
export type DecodedSwapPayload = SwapPayload & {
    /** hex of `payin_extra_data` (field 13) */
    payinExtraData?: string;
};
export type SwapPayloadCheckReport = PayloadCheckReport<DecodedSwapPayload>;
/**
 * Checks a Swap NG (default) or legacy Swap payload and its partner signature against the rules
 * of Ledger Live and the Exchange app, without a device. Fee, address ownership and coin app
 * checks still happen on the device. Pure and synchronous, inputs are never logged.
 */
export declare function checkSwapPayload(input: SwapPayloadCheckInput): SwapPayloadCheckReport;
//# sourceMappingURL=SwapPayloadChecker.d.ts.map