import { decodeNewTransactionResponseBytes, NEW_TRANSACTION_RESPONSE_FIELD_LIMITS, toSwapPayload, } from "./SwapUtils";
import { verifyCompactSignature } from "./SwapSignature";
import { isHexadecimal } from "./shared-utils";
import { apduSizeIssues, cStringOf, expectedValueIssues, fieldLimitIssues, issueError, issueWarning, lastOf, ngNonceIssues, requiredFieldIssues, runNgPayloadCheck, runPayloadCheck, sameHexNonce, } from "./PayloadCheckerShared";
const protoFieldName = (key) => key.replace(/[A-Z]/g, letter => `_${letter.toLowerCase()}`);
const REQUIRED_KEYS = [
    "payinAddress",
    "payoutAddress",
    "refundAddress",
    "currencyFrom",
    "currencyTo",
    "amountToProvider",
    "amountToWallet",
];
const AMOUNT_KEYS = ["amountToProvider", "amountToWallet"];
const EXPECTED_KEYS = [
    "currencyFrom",
    "currencyTo",
    "amountToProvider",
    "amountToWallet",
    "payinAddress",
    "payoutAddress",
    "refundAddress",
];
const NG_NONCE = {
    key: "deviceTransactionIdNg",
    issues: proto => ngNonceIssues("device_transaction_id_ng", proto.deviceTransactionIdNg),
    equals: sameHexNonce,
};
const LEGACY_NONCE_PATTERN = /^[\x20-\x7e]{10}$/;
const LEGACY_NONCE = {
    key: "deviceTransactionId",
    issues: ({ deviceTransactionId }) => deviceTransactionId && !LEGACY_NONCE_PATTERN.test(deviceTransactionId)
        ? [
            issueError("INVALID_DEVICE_TRANSACTION_ID", `Field "device_transaction_id" must be exactly 10 printable ASCII characters (the nonce returned by the device), got ${deviceTransactionId.length} characters.`, "device_transaction_id"),
        ]
        : [],
    equals: (expected, actual) => expected === actual,
};
// `toSwapPayload` cannot convert empty amount bytes, already reported as MISSING_FIELD.
const orZeroAmount = (bytes) => bytes && bytes.length > 0 ? bytes : Buffer.from([0x00]);
const PAYIN_EXTRA_DATA_BYTES = 33;
// Not in the generated JS protocol, only read from the raw bytes.
const PAYIN_EXTRA_DATA_FIELD = {
    fieldNumber: 13,
    protoName: "payin_extra_data",
    kind: "bytes",
    maxSize: PAYIN_EXTRA_DATA_BYTES,
};
const NEW_TRANSACTION_RESPONSE_FIELDS = [
    ...NEW_TRANSACTION_RESPONSE_FIELD_LIMITS,
    PAYIN_EXTRA_DATA_FIELD,
];
const isNativeId = (extraData) => extraData.length === 1 && extraData[0] === 0x00;
// Mirrors app-exchange `check_extra_id_extra_data`.
function payinExtraDataIssues(proto, occurrences) {
    if (occurrences.some(({ length }) => length > PAYIN_EXTRA_DATA_BYTES))
        return [];
    // As in protobuf decoders, the last occurrence wins.
    const extraData = lastOf(occurrences);
    if (!extraData?.length || isNativeId(extraData))
        return [];
    const issues = [];
    if (cStringOf(proto.payinExtraId ?? "") !== "") {
        issues.push(issueError("EXTRA_ID_AND_EXTRA_DATA", 'Fields "payin_extra_id" and "payin_extra_data" are both set: the Exchange app accepts only one of them (WRONG_EXTRA_ID_OR_EXTRA_DATA). Remove one.', "payin_extra_data"));
    }
    if (extraData.length !== PAYIN_EXTRA_DATA_BYTES) {
        issues.push(issueError("INVALID_PAYIN_EXTRA_DATA", `Field "payin_extra_data" is ${extraData.length} bytes: the Exchange app accepts it empty, as the single byte 0x00, or exactly ${PAYIN_EXTRA_DATA_BYTES} bytes (a 1-byte header and a 32-byte hash).`, "payin_extra_data"));
    }
    issues.push(issueWarning("PAYIN_EXTRA_DATA_NANO_S", 'Field "payin_extra_data" is set: the Exchange app rejects it on Nano S (WRONG_EXTRA_ID_OR_EXTRA_DATA), so this swap fails on a Nano S.', "payin_extra_data"));
    return issues;
}
function inspectSwap(proto, wire, nonce, expected) {
    const extraDataOccurrences = wire.occurrences.get(PAYIN_EXTRA_DATA_FIELD) ?? [];
    const payinExtraData = lastOf(extraDataOccurrences);
    const decoded = {
        ...toSwapPayload({
            ...proto,
            amountToProvider: orZeroAmount(proto.amountToProvider),
            amountToWallet: orZeroAmount(proto.amountToWallet),
        }),
        ...(payinExtraData ? { payinExtraData: Buffer.from(payinExtraData).toString("hex") } : {}),
    };
    const issues = [
        ...requiredFieldIssues([...REQUIRED_KEYS, nonce.key].map(key => ({ field: protoFieldName(key), value: proto[key] })), AMOUNT_KEYS.map(key => ({ field: protoFieldName(key), value: proto[key] }))),
        ...nonce.issues(proto),
        ...fieldLimitIssues(wire.violations),
        ...payinExtraDataIssues(proto, extraDataOccurrences),
        ...expectedValueIssues([
            {
                field: protoFieldName(nonce.key),
                expected: expected?.deviceTransactionId,
                actual: decoded[nonce.key] ?? "",
                equals: nonce.equals,
            },
            ...EXPECTED_KEYS.map(key => ({
                field: protoFieldName(key),
                expected: expected?.[key],
                actual: decoded[key],
            })),
        ]),
    ];
    return { decoded, issues };
}
const LEGACY_SIGNATURE_PATTERN = /^[0-9a-fA-F]{128}$/;
const decodeHex = (hex) => isHexadecimal(hex) && hex.length % 2 === 0 ? Buffer.from(hex, "hex") : undefined;
// Ledger Live sends `Buffer.from(payload, "hex")`, which decodes a "0x" prefixed payload to no bytes.
function decodeLegacyPayload(payload) {
    const hasHexPrefix = /^0x/i.test(payload);
    const bytes = decodeHex(hasHexPrefix ? payload.slice(2) : payload);
    return {
        bytes,
        formatIssues: hasHexPrefix && bytes
            ? [
                issueError("INVALID_ENCODING", 'The payload starts with "0x". Ledger Live hex-decodes the legacy payload as is, so the device would receive no bytes: remove the "0x" prefix.'),
            ]
            : [],
    };
}
function legacySignatureIssues(rawPayload, signature, partnerPublicKey) {
    // app-exchange `set_partner_key.c` always uses secp256k1 for a legacy swap.
    if (partnerPublicKey.curve !== "secp256k1") {
        return [
            issueError("LEGACY_CURVE_UNSUPPORTED", `The partner public key is on ${partnerPublicKey.curve}, but the Exchange app verifies a legacy swap signature on secp256k1 only. Sign with a secp256k1 key, or use Swap NG to sign with ${partnerPublicKey.curve}.`),
        ];
    }
    const malformed = issueError("SIGNATURE_MALFORMED", 'Ledger Live expects the legacy swap signature as 128 hex characters: the 64-byte compact r||s signature (no "0x" prefix, not base64url, not DER).');
    if (!LEGACY_SIGNATURE_PATTERN.test(signature))
        return [malformed];
    try {
        return verifyCompactSignature(partnerPublicKey, Buffer.from(signature, "hex"), rawPayload)
            ? []
            : [
                issueError("SIGNATURE_INVALID", "The signature does not verify: wrong key or curve, or the signature does not match the payload. Sign SHA-256(raw protobuf bytes) with the partner private key."),
            ];
    }
    catch {
        return [malformed];
    }
}
/**
 * Checks a Swap NG (default) or legacy Swap payload and its partner signature against the rules
 * of Ledger Live and the Exchange app, without a device. Fee, address ownership and coin app
 * checks still happen on the device. Pure and synchronous, inputs are never logged.
 */
export function checkSwapPayload(input) {
    const { payload, signature, partnerPublicKey, expected } = input;
    const messageName = "NewTransactionResponse";
    const decode = decodeNewTransactionResponseBytes;
    if (input.format === "legacy") {
        const { bytes, formatIssues } = decodeLegacyPayload(payload);
        return runPayloadCheck({
            bytes,
            formatIssues,
            sizeIssues: bytes ? apduSizeIssues("legacy", bytes.length) : [],
            encodingIssue: issueError("INVALID_ENCODING", 'A legacy swap payload must be the hex of the raw protobuf bytes, without a "0x" prefix: an even number of 0-9, a-f, A-F characters.'),
            messageName,
            wireFields: NEW_TRANSACTION_RESPONSE_FIELDS,
            decode,
            inspect: (proto, wire) => inspectSwap(proto, wire, LEGACY_NONCE, expected),
            partnerPublicKey,
            checkSignature: raw => legacySignatureIssues(raw, signature, partnerPublicKey),
        });
    }
    return runNgPayloadCheck({
        payload,
        signature,
        partnerPublicKey,
        messageName,
        wireFields: NEW_TRANSACTION_RESPONSE_FIELDS,
        decode,
        inspect: (proto, wire) => inspectSwap(proto, wire, NG_NONCE, expected),
    });
}
//# sourceMappingURL=SwapPayloadChecker.js.map