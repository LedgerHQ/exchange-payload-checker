import Transport from "@ledgerhq/hw-transport";
import { BigNumber } from "bignumber.js";
export declare const enum RateTypes {
    Fixed = 0,
    Floating = 1
}
export declare const enum ExchangeTypes {
    Swap = 0,
    Sell = 1,
    Fund = 2,
    SwapNg = 3,
    SellNg = 4,
    FundNg = 5
}
export declare function isExchangeTypeNg(type: ExchangeTypes): boolean;
export type PartnerKeyInfo = {
    name: string;
    curve: string;
    publicKey: Buffer;
    signatureComputedFormat?: PayloadSignatureComputedFormat;
};
export type PayloadSignatureComputedFormat = "raw" | "jws";
/**
 * Payload format a partner uses, from its provider config `version`: undefined or 1 is a legacy
 * partner, any other version uses the NG (Next Gen) APDU commands.
 */
export declare function swapPayloadFormatOf(partnerVersion?: number): "ng" | "legacy";
export declare function createExchange(transport: Transport, transactionType: ExchangeTypes, transactionRate?: RateTypes, version?: number): Exchange;
export default class Exchange {
    transport: Transport;
    transactionType: ExchangeTypes;
    transactionRate: RateTypes;
    allowedStatuses: Array<number>;
    constructor(transport: Transport, transactionType: ExchangeTypes, transactionRate?: RateTypes);
    startNewTransaction(): Promise<string>;
    setPartnerKey(info: PartnerKeyInfo): Promise<void>;
    checkPartner(signatureOfPartnerData: Buffer): Promise<void>;
    processTransaction(transaction: Buffer, fee: BigNumber, compFormat?: PayloadSignatureComputedFormat): Promise<void>;
    /**
     *
     * @param bufferToSend Remaining buffer to send
     */
    private processSplitTransaction;
    checkTransactionSignature(transactionSignature: Buffer): Promise<void>;
    validatePayoutOrAsset(payoutCurrencyConfig: Buffer, currencyConfigSignature: Buffer, addressParameters: Buffer): Promise<void>;
    checkRefundAddress(refundCurrencyConfig: Buffer, currencyConfigSignature: Buffer, addressParameters: Buffer): Promise<void>;
    signCoinTransaction(): Promise<void>;
    getChallenge(): Promise<number>;
    sendPKICertificate(descriptor: Buffer, signature: Buffer): Promise<void>;
    sendTrustedDescriptor(buffer: Buffer): Promise<void>;
    private getPartnerKeyInfo;
    private isExchangeTypeNg;
}
//# sourceMappingURL=Exchange.d.ts.map