import { SwapPayloadFieldExceedsLimit } from "./errors";
/** @ignore internal */
export type SwapProtobufPayload = {
    payinAddress: string;
    payinExtraId?: string;
    refundAddress: string;
    refundExtraId?: string;
    payoutAddress: string;
    payoutExtraId?: string;
    currencyFrom: string;
    currencyTo: string;
    amountToProvider: Buffer;
    amountToWallet: Buffer;
    message?: string;
    deviceTransactionId?: string;
    deviceTransactionIdNg?: Buffer;
};
export type SwapPayload = {
    payinAddress: string;
    payinExtraId?: string;
    refundAddress: string;
    refundExtraId?: string;
    payoutAddress: string;
    payoutExtraId?: string;
    currencyFrom: string;
    currencyTo: string;
    amountToProvider: bigint;
    amountToWallet: bigint;
    message?: string;
    deviceTransactionId?: string;
    deviceTransactionIdNg?: string;
};
/**
 * deprecated use `decodeSwapPayload` instead
 */
export declare const decodePayloadProtobuf: (payload: string) => Promise<SwapPayload>;
/** @ignore internal */
export declare function decodeNewTransactionResponseBytes(bytes: Uint8Array): SwapProtobufPayload;
export declare function decodeSwapPayload(payload: string): Promise<SwapPayload>;
/** @ignore internal */
export declare function toSwapPayload(decodePayload: SwapProtobufPayload): SwapPayload;
type ProtoFieldLimit = {
    key: keyof SwapProtobufPayload;
    fieldNumber: number;
    protoName: string;
    kind: "string" | "bytes";
    maxSize: number;
};
/**
 * Field size limits enforced by the Exchange device app for a swap
 * `NewTransactionResponse`, mirrored from app-exchange `src/proto/protocol.options`.
 * These are what the device rejects with a generic DESERIALIZATION_FAILED (0x6a81).
 *
 * @ignore internal lookup table, consumers should use `findSwapPayloadSpecViolation`.
 */
export declare const NEW_TRANSACTION_RESPONSE_FIELD_LIMITS: ProtoFieldLimit[];
/** @ignore internal */
export declare function measureBytes(value: unknown): number;
/**
 * Decodes a raw swap payload (hex or base64) and returns the first field that
 * exceeds the Exchange device app's protobuf size limits as a precise
 * `SwapPayloadFieldExceedsLimit`, or `undefined` when everything fits (or the
 * payload cannot be decoded locally).
 *
 * This is meant to *enrich* the device's opaque DESERIALIZATION_FAILED (0x6a81)
 * with an actionable reason (e.g. an oversized `payin_extra_id`) — it must never
 * gate the flow. The device stays the source of truth, so if these (hardcoded)
 * limits ever drift from the app we simply return `undefined` and keep the
 * device's own error.
 *
 * nanopb reserves one byte for the NUL terminator on `string` fields, so their
 * usable content limit is `max_size - 1`; `bytes` fields use the full `max_size`.
 */
export declare function findSwapPayloadSpecViolation(payload: string): SwapPayloadFieldExceedsLimit | undefined;
/** @ignore internal */
export type FieldLimitViolation = {
    field: string;
    limit: number;
    actual: number;
};
export {};
//# sourceMappingURL=SwapUtils.d.ts.map