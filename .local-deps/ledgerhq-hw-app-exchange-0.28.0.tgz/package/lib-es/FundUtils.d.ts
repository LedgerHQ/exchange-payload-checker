export type FundPayload = {
    deviceTransactionId: Uint8Array;
    inAddress: string;
    inAmount: Uint8Array;
    inCurrency: string;
    accountName: string;
    userId: string;
    inExtraId?: string;
};
export declare function decodeFundPayload(payload: string): Promise<FundPayload>;
//# sourceMappingURL=FundUtils.d.ts.map