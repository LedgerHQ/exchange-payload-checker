/**
 * Partner public key used to verify a Swap NG payload signature.
 */
export type SwapNgPartnerPublicKey = {
    curve: "secp256k1" | "secp256r1";
    data: Uint8Array;
};
/**
 * Result of `classifySwapNgSignature`.
 *
 * - `valid`: verifies over `"." + payload`, the input the Exchange app hashes. The
 *   `valid_leading_zero_*` variants flag an r and/or s starting with 0x00, a known firmware
 *   R/S-to-DER edge case the device may still reject.
 * - `signed_without_dot_prefix`: verifies over the payload without the "." prefix.
 * - `signed_raw_protobuf`: verifies over the decoded protobuf bytes.
 * - `invalid`: verifies over none of the above.
 * - `signature_malformed`: not a 64-byte compact r||s, r or s is 0 or not below the curve order, or
 *   the public key curve is not supported.
 */
export type SwapNgSignatureClassification = "valid" | "valid_leading_zero_r" | "valid_leading_zero_s" | "valid_leading_zero_rs" | "signed_without_dot_prefix" | "signed_raw_protobuf" | "invalid" | "signature_malformed";
/** @ignore internal, runtime check for a curve coming from CAL or a JS caller. */
export declare const isSupportedPartnerCurve: (curve: unknown) => curve is SwapNgPartnerPublicKey["curve"];
export declare function isValidSwapNgPartnerPublicKey(publicKey: SwapNgPartnerPublicKey): boolean;
/**
 * @ignore internal, verifies a 64-byte compact r||s signature over SHA-256(message) like the
 * Exchange app, which accepts high-S signatures. Throws when r or s is 0 or not below the curve order,
 * or on an unsupported curve.
 */
export declare function verifyCompactSignature(publicKey: SwapNgPartnerPublicKey, compactSignature: Uint8Array, message: Uint8Array): boolean;
/**
 * Classifies a Swap NG partner signature against the inputs a partner backend may have signed.
 * Never throws.
 *
 * @param payload base64url `NewTransactionResponse`, without its "." prefix
 * @param signature base64url of the 64-byte compact r||s signature
 */
export declare function classifySwapNgSignature(payload: string, signature: string, publicKey: SwapNgPartnerPublicKey): SwapNgSignatureClassification;
//# sourceMappingURL=SwapSignature.d.ts.map