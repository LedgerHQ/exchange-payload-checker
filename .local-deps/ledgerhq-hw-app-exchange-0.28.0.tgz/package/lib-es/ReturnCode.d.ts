/**
 * Those values map the one defined in the app-exchange code (@see protocol.md and swap_errors.h)
 */
export declare const OkStatus = 36864;
export declare const ErrorStatus: {
    readonly INCORRECT_COMMAND_DATA: 27264;
    readonly DESERIALIZATION_FAILED: 27265;
    readonly WRONG_TRANSACTION_ID: 27266;
    readonly INVALID_ADDRESS: 27267;
    readonly USER_REFUSED: 27268;
    readonly INTERNAL_ERROR: 27269;
    readonly WRONG_P1: 27270;
    readonly WRONG_P2: 27271;
    readonly WRONG_P2_EXTENSION: 27272;
    readonly INVALID_P2_EXTENSION: 27273;
    readonly MEMORY_CORRUPTION: 27274;
    readonly AMOUNT_FORMATTING_FAILED: 27275;
    readonly APPLICATION_NOT_INSTALLED: 27276;
    readonly WRONG_EXTRA_ID_OR_EXTRA_DATA: 27277;
    readonly WRONG_TLV_CHALLENGE: 27278;
    readonly WRONG_TLV_CONTENT: 27279;
    readonly MISSING_TLV_CONTENT: 27280;
    readonly WRONG_TRUSTED_NAME_TLV: 27281;
    readonly USER_REFUSED_CROSS_SEED: 27282;
    readonly INVALID_INSTRUCTION: 27904;
    readonly UNEXPECTED_INSTRUCTION: 27905;
    readonly DESCRIPTOR_NOT_USED: 27906;
    readonly CLASS_NOT_SUPPORTED: 28160;
    readonly MALFORMED_APDU: 28161;
    readonly INVALID_DATA_LENGTH: 28162;
    readonly SIGN_VERIFICATION_FAIL: 40218;
};
export declare function getExchangeErrorMessage(errorCode: number, step?: string): {
    errorName?: string;
    errorMessage?: string;
};
//# sourceMappingURL=ReturnCode.d.ts.map