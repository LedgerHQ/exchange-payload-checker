import { TransportStatusError } from "@ledgerhq/hw-transport/errors";
import invariant from "invariant";
import { OkStatus, ErrorStatus } from "./ReturnCode";
const ExchangeTypeNg = [3 /* ExchangeTypes.SwapNg */, 4 /* ExchangeTypes.SellNg */, 5 /* ExchangeTypes.FundNg */];
export function isExchangeTypeNg(type) {
    return ExchangeTypeNg.includes(type);
}
const CLA = 0xe0;
const START_NEW_TRANSACTION_COMMAND = 0x03;
const SET_PARTNER_KEY_COMMAND = 0x04;
const CHECK_PARTNER_COMMAND = 0x05;
const PROCESS_TRANSACTION_RESPONSE = 0x06;
const CHECK_TRANSACTION_SIGNATURE = 0x07;
const CHECK_PAYOUT_ADDRESS = 0x08;
const CHECK_REFUND_ADDRESS = 0x09;
// const CHECK_REFUND_ADDRESS_AND_DISPLAY = 0x09;
// const CHECK_REFUND_ADDRESS_NO_DISPLAY = 0x0c;
const SIGN_COIN_TRANSACTION = 0x0a;
const CHECK_ASSET_IN_AND_DISPLAY = 0x0b;
const SEND_PKI_CERTIFICATE = 0x0e;
const GET_CHALLENGE = 0x10;
const SEND_TRUSTED_NAME_DESCRIPTOR = 0x11;
// Extension for PROCESS_TRANSACTION_RESPONSE APDU
const P2_NONE = 0x00 << 4;
const P2_EXTEND = 0x01 << 4;
const P2_MORE = 0x02 << 4;
const maybeThrowProtocolError = (result) => {
    invariant(result.length >= 2, "ExchangeTransport: Unexpected result length");
    const resultCode = result.readUInt16BE(result.length - 2);
    if (resultCode !== OkStatus) {
        throw new TransportStatusError(resultCode);
    }
};
const isDmkTransport = (transport) => {
    return ("dmk" in transport &&
        transport.dmk !== undefined &&
        "sessionId" in transport &&
        transport.sessionId !== undefined);
};
const curves = {
    secp256k1: 0x00,
    secp256r1: 0x01,
};
const transactionEncodedFormat = {
    raw: 0x00,
    base64: 0x01,
};
function computedFormatToEncodedFormat(format) {
    return format === "jws" ? transactionEncodedFormat.base64 : transactionEncodedFormat.raw;
}
/**
 * Payload format a partner uses, from its provider config `version`: undefined or 1 is a legacy
 * partner, any other version uses the NG (Next Gen) APDU commands.
 */
export function swapPayloadFormatOf(partnerVersion) {
    return partnerVersion === undefined || partnerVersion === 1 ? "legacy" : "ng";
}
/**
 * Adapt ExchangeTypes following partner info.
 * For "legacy" partner, we don't change the provided type.
 * For new one, we call the new APDU commands (Ng, Next Gen).
 */
function resolveTransactionType(type, partnerVersion) {
    if (swapPayloadFormatOf(partnerVersion) === "legacy") {
        return type;
    }
    switch (type) {
        case 0 /* ExchangeTypes.Swap */:
            return 3 /* ExchangeTypes.SwapNg */;
        case 1 /* ExchangeTypes.Sell */:
            return 4 /* ExchangeTypes.SellNg */;
        case 2 /* ExchangeTypes.Fund */:
            return 5 /* ExchangeTypes.FundNg */;
        default:
            return type;
    }
}
export function createExchange(transport, transactionType, transactionRate, version) {
    return new Exchange(transport, resolveTransactionType(transactionType, version), transactionRate);
}
export default class Exchange {
    transport;
    transactionType;
    transactionRate;
    allowedStatuses = [...Object.values(ErrorStatus), OkStatus];
    constructor(transport, transactionType, transactionRate) {
        this.transactionType = transactionType;
        this.transactionRate = transactionRate || 0 /* RateTypes.Fixed */;
        this.transport = transport;
    }
    async startNewTransaction() {
        const result = await this.transport.send(CLA, START_NEW_TRANSACTION_COMMAND, this.transactionRate, this.transactionType, Buffer.alloc(0), this.allowedStatuses);
        maybeThrowProtocolError(result);
        // Leave the deprecated warning and don't update to `subarray` method as
        // the output on LLM will not be the expected one (cf. LIVE-10430)
        switch (this.transactionType) {
            case 1 /* ExchangeTypes.Sell */:
            case 2 /* ExchangeTypes.Fund */:
                return result.slice(0, 32).toString("base64");
            case 0 /* ExchangeTypes.Swap */:
                return result.toString("ascii", 0, 10);
            default:
                return result.slice(0, 32).toString("hex");
        }
    }
    async setPartnerKey(info) {
        const partnerNameAndPublicKey = this.getPartnerKeyInfo(info);
        const result = await this.transport.send(CLA, SET_PARTNER_KEY_COMMAND, this.transactionRate, this.transactionType, partnerNameAndPublicKey, this.allowedStatuses);
        maybeThrowProtocolError(result);
    }
    async checkPartner(signatureOfPartnerData) {
        const result = await this.transport.send(CLA, CHECK_PARTNER_COMMAND, this.transactionRate, this.transactionType, signatureOfPartnerData, this.allowedStatuses);
        maybeThrowProtocolError(result);
    }
    async processTransaction(transaction, fee, compFormat) {
        let hex = fee.toString(16);
        hex = hex.padStart(hex.length + (hex.length % 2), "0");
        const feeHex = Buffer.from(hex, "hex");
        let p2Value = this.transactionType | P2_NONE;
        let bufferToSend;
        if (this.isExchangeTypeNg()) {
            const encodedFormat = computedFormatToEncodedFormat(compFormat);
            // In JWS we expect the transaction to be in the following form: "." + base64Url(payload)
            // However, app-exchange doesn't expect the leading dot (i.e. ".")
            if (encodedFormat === transactionEncodedFormat.base64) {
                transaction = transaction.subarray(1);
            }
            bufferToSend = Buffer.concat([
                Buffer.from([encodedFormat]),
                Buffer.from([(transaction.length >> 8) % 256, transaction.length % 256]),
                transaction,
                Buffer.from([feeHex.length]),
                feeHex,
            ]);
            if (bufferToSend.length >= 256) {
                bufferToSend = await this.processSplitTransaction(bufferToSend);
                p2Value = this.transactionType | P2_EXTEND;
            }
        }
        else {
            bufferToSend = Buffer.concat([
                Buffer.from([transaction.length]),
                transaction,
                Buffer.from([feeHex.length]),
                feeHex,
            ]);
        }
        const result = await this.transport.send(CLA, PROCESS_TRANSACTION_RESPONSE, this.transactionRate, p2Value, bufferToSend, this.allowedStatuses);
        maybeThrowProtocolError(result);
    }
    /**
     *
     * @param bufferToSend Remaining buffer to send
     */
    async processSplitTransaction(bufferToSend) {
        const dataLength = bufferToSend.length;
        for (let i = 0; i < Math.floor(dataLength / 256); i++) {
            const start = 255 * i;
            const end = start + 255;
            const data = bufferToSend.subarray(start, end);
            const extFlag = i == 0 ? P2_MORE : P2_MORE | P2_EXTEND;
            const result = await this.transport.send(CLA, PROCESS_TRANSACTION_RESPONSE, this.transactionRate, this.transactionType | extFlag, data, this.allowedStatuses);
            maybeThrowProtocolError(result);
        }
        return bufferToSend.subarray(dataLength - (dataLength % 255));
    }
    async checkTransactionSignature(transactionSignature) {
        const DOT_PREFIX = 0x01;
        const RS_FORMAT = 0x01;
        if (this.isExchangeTypeNg()) {
            transactionSignature = Buffer.concat([
                Buffer.from([DOT_PREFIX, RS_FORMAT]),
                transactionSignature,
            ]);
        }
        const result = await this.transport.send(CLA, CHECK_TRANSACTION_SIGNATURE, this.transactionRate, this.transactionType, transactionSignature, this.allowedStatuses);
        maybeThrowProtocolError(result);
    }
    async validatePayoutOrAsset(payoutCurrencyConfig, currencyConfigSignature, addressParameters) {
        invariant(payoutCurrencyConfig.length <= 255, "Currency config is too big");
        invariant(addressParameters.length <= 255, "Address parameter is too big.");
        invariant(currencyConfigSignature.length >= 67 && currencyConfigSignature.length <= 73, "Signature should be DER serialized and have length in [67, 73] bytes.");
        const bufferToSend = Buffer.concat([
            Buffer.from([payoutCurrencyConfig.length]),
            payoutCurrencyConfig,
            currencyConfigSignature,
            Buffer.from([addressParameters.length]),
            addressParameters,
        ]);
        const result = await this.transport.send(CLA, this.transactionType === 0 /* ExchangeTypes.Swap */ || this.transactionType === 3 /* ExchangeTypes.SwapNg */
            ? CHECK_PAYOUT_ADDRESS
            : CHECK_ASSET_IN_AND_DISPLAY, this.transactionRate, this.transactionType, bufferToSend, this.allowedStatuses);
        maybeThrowProtocolError(result);
    }
    async checkRefundAddress(refundCurrencyConfig, currencyConfigSignature, addressParameters) {
        invariant(refundCurrencyConfig.length <= 255, "Currency config is too big");
        invariant(addressParameters.length <= 255, "Address parameter is too big.");
        invariant(currencyConfigSignature.length >= 67 && currencyConfigSignature.length <= 73, "Signature should be DER serialized and have length in [67, 73] bytes.");
        const bufferToSend = Buffer.concat([
            Buffer.from([refundCurrencyConfig.length]),
            refundCurrencyConfig,
            currencyConfigSignature,
            Buffer.from([addressParameters.length]),
            addressParameters,
        ]);
        const result = await this.transport.send(CLA, CHECK_REFUND_ADDRESS, this.transactionRate, this.transactionType, bufferToSend, this.allowedStatuses);
        maybeThrowProtocolError(result);
    }
    async signCoinTransaction() {
        if (isDmkTransport(this.transport)) {
            const result = await this.transport.dmk
                .sendApdu({
                sessionId: this.transport.sessionId,
                apdu: new Uint8Array([
                    CLA,
                    SIGN_COIN_TRANSACTION,
                    this.transactionRate,
                    this.transactionType,
                    0,
                ]),
                triggersDisconnection: true,
            })
                .then(apduResponse => Buffer.from([...apduResponse.data, ...apduResponse.statusCode]))
                .catch(e => {
                throw e;
            });
            maybeThrowProtocolError(result);
        }
        else {
            const result = await this.transport.send(CLA, SIGN_COIN_TRANSACTION, this.transactionRate, this.transactionType, Buffer.alloc(0), this.allowedStatuses);
            maybeThrowProtocolError(result);
        }
    }
    async getChallenge() {
        const result = await this.transport.send(CLA, GET_CHALLENGE, this.transactionRate, this.transactionType, Buffer.alloc(0), this.allowedStatuses);
        maybeThrowProtocolError(result);
        return result.slice(0, 4).readUInt32BE();
    }
    async sendPKICertificate(descriptor, signature) {
        const result = await this.transport.send(CLA, SEND_PKI_CERTIFICATE, this.transactionRate, this.transactionType, Buffer.concat([
            descriptor,
            Buffer.from("15", "hex"),
            Buffer.from([signature.length]),
            signature,
        ]), this.allowedStatuses);
        maybeThrowProtocolError(result);
    }
    async sendTrustedDescriptor(buffer) {
        const result = await this.transport.send(CLA, SEND_TRUSTED_NAME_DESCRIPTOR, this.transactionRate, this.transactionType, buffer, this.allowedStatuses);
        maybeThrowProtocolError(result);
    }
    getPartnerKeyInfo({ name, curve, publicKey }) {
        if (this.isExchangeTypeNg()) {
            return Buffer.concat([
                Buffer.from([name.length]),
                Buffer.from(name, "ascii"),
                Buffer.from([curves[curve]]),
                publicKey,
            ]);
        }
        return Buffer.concat([Buffer.from([name.length]), Buffer.from(name, "ascii"), publicKey]);
    }
    isExchangeTypeNg() {
        return isExchangeTypeNg(this.transactionType);
    }
}
//# sourceMappingURL=Exchange.js.map