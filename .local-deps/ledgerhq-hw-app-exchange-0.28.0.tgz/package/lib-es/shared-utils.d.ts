export declare function isHexadecimal(str: string): boolean;
export declare function base64UrlDecode(base64Url: string): Buffer;
//# sourceMappingURL=shared-utils.d.ts.map