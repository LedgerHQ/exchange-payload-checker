import { ledger_trade } from "./generate-protocol";
import { isHexadecimal } from "./shared-utils";
export async function decodeFundPayload(payload) {
    const buffer = isHexadecimal(payload)
        ? Buffer.from(payload, "hex")
        : Buffer.from(payload, "base64");
    const FundResponse = ledger_trade.NewFundResponse;
    const decodedPayload = FundResponse.decode(buffer);
    const err = FundResponse.verify(decodedPayload);
    if (err) {
        throw Error(err);
    }
    return {
        ...decodedPayload,
    };
}
//# sourceMappingURL=FundUtils.js.map