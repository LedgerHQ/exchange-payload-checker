import { type FieldLimitViolation } from "./SwapUtils";
import { type SwapNgPartnerPublicKey } from "./SwapSignature";
/**
 * Stable issue codes reported by `checkSwapPayload` and `checkSellPayload`.
 */
export type SwapPayloadIssueCode = "INVALID_ENCODING" | "PAYLOAD_LEADING_DOT" | "PROTOBUF_DECODE_FAILED" | "MISSING_FIELD" | "ZERO_AMOUNT" | "INVALID_DEVICE_TRANSACTION_ID" | "FIELD_EXCEEDS_LIMIT" | "PAYLOAD_TOO_LARGE" | "PAYLOAD_NEAR_SIZE_LIMIT" | "INVALID_PAYIN_EXTRA_DATA" | "EXTRA_ID_AND_EXTRA_DATA" | "PAYIN_EXTRA_DATA_NANO_S" | "EXPECTED_VALUE_MISMATCH" | "PUBLIC_KEY_MALFORMED" | "PUBLIC_KEY_COMPRESSED" | "SIGNATURE_MALFORMED" | "SIGNATURE_LEADING_ZERO" | "SIGNATURE_WITHOUT_DOT_PREFIX" | "SIGNATURE_OVER_RAW_PROTOBUF" | "SIGNATURE_INVALID" | "LEGACY_CURVE_UNSUPPORTED";
/**
 * A single problem found by `checkSwapPayload` or `checkSellPayload`.
 */
export type SwapPayloadIssue = {
    code: SwapPayloadIssueCode;
    severity: "error" | "warning";
    /** protobuf field name, e.g. "payin_extra_id" */
    field?: string;
    message: string;
};
/**
 * Result of `checkSwapPayload` and `checkSellPayload`.
 */
export type PayloadCheckReport<D> = {
    valid: boolean;
    decoded?: D;
    issues: SwapPayloadIssue[];
};
type Inspect<P, D> = (proto: P, wire: WireScan) => {
    decoded: D;
    issues: SwapPayloadIssue[];
};
export declare const issueError: (code: SwapPayloadIssueCode, message: string, field?: string) => SwapPayloadIssue;
export declare const issueWarning: (code: SwapPayloadIssueCode, message: string, field?: string) => SwapPayloadIssue;
type PayloadDecoding<P, D> = {
    messageName: string;
    wireFields: WireField[];
    decode: (bytes: Uint8Array) => P;
    inspect: Inspect<P, D>;
};
/**
 * Runs every check shared by the payload checkers and collects all issues, in this order:
 * `formatIssues`, encoding, protobuf decoding, `scanWireFields` and `inspect`, `sizeIssues`,
 * public key, signature. Never throws: a throwing `inspect` is reported as `PROTOBUF_DECODE_FAILED`.
 */
export declare function runPayloadCheck<P, D>({ bytes, encodingIssue, formatIssues, sizeIssues, partnerPublicKey, checkSignature, ...decoding }: PayloadDecoding<P, D> & {
    bytes: Uint8Array | undefined;
    encodingIssue: SwapPayloadIssue;
    formatIssues?: SwapPayloadIssue[];
    sizeIssues?: SwapPayloadIssue[];
    partnerPublicKey: SwapNgPartnerPublicKey;
    checkSignature: (bytes: Uint8Array) => SwapPayloadIssue[];
}): PayloadCheckReport<D>;
/**
 * `runPayloadCheck` for a base64url NG payload signed over `"." + payload`. Ledger Live adds the
 * "." itself, so a leading "." is an error and the other checks run on the payload without it.
 */
export declare function runNgPayloadCheck<P, D>({ payload: rawPayload, signature, partnerPublicKey, messageName, wireFields, decode, inspect, }: {
    payload: string;
    signature: string;
    partnerPublicKey: SwapNgPartnerPublicKey;
    messageName: string;
    wireFields: WireField[];
    decode: (bytes: Uint8Array) => P;
    inspect: Inspect<P, D>;
}): PayloadCheckReport<D>;
type FieldValue = {
    field: string;
    value: unknown;
};
/** The text the Exchange app reads from a nanopb string: everything before the first NUL. */
export declare const cStringOf: (text: string) => string;
export declare function requiredFieldIssues(required: FieldValue[], amounts: FieldValue[]): SwapPayloadIssue[];
export declare function ngNonceIssues(field: string, nonce: unknown): SwapPayloadIssue[];
export declare const fieldLimitIssues: (violations: FieldLimitViolation[]) => SwapPayloadIssue[];
export type ComparedValue = string | bigint | undefined;
export declare const sameHexNonce: (expected: ComparedValue, actual: ComparedValue) => boolean;
/** Without a custom `equals`, a string is compared as the Exchange app reads it, up to its first NUL. */
export declare const expectedValueIssues: (comparisons: {
    field: string;
    expected: ComparedValue;
    actual: ComparedValue;
    equals?: (expected: ComparedValue, actual: ComparedValue) => boolean;
}[]) => SwapPayloadIssue[];
export declare const lastOf: <T>(values: T[]) => T | undefined;
/**
 * `PAYLOAD_TOO_LARGE` when the APDU data cannot reach the device with any fee of 1 to 8 bytes,
 * `PAYLOAD_NEAR_SIZE_LIMIT` when it cannot with some of them.
 *
 * @param payloadBytes "ng": base64url characters sent (no leading "."), "legacy": protobuf bytes
 */
export declare function apduSizeIssues(format: "ng" | "legacy", payloadBytes: number): SwapPayloadIssue[];
/**
 * A protobuf field the Exchange app decodes, with its nanopb `max_size` from app-exchange
 * `src/proto/protocol.options` for a string or bytes field.
 */
export type WireField = {
    fieldNumber: number;
    protoName: string;
} & ({
    kind: "string" | "bytes";
    maxSize: number;
} | {
    kind: "varint";
} | {
    kind: "message";
    fields: WireField[];
});
export type WireScan = {
    /** every occurrence of each string, bytes or varint field, in wire order */
    occurrences: Map<WireField, Uint8Array[]>;
    violations: FieldLimitViolation[];
};
/**
 * Walks raw protobuf bytes like nanopb `pb_decode` in app-exchange, which also rejects what
 * protobufjs accepts: `undefined` for truncated data, a group or invalid wire type, or a known
 * field with another wire type. Limits are checked on every occurrence of a field: nanopb fails
 * on an oversized one even when a later duplicate fits.
 */
export declare function scanWireFields(bytes: Uint8Array, fields: WireField[]): WireScan | undefined;
/**
 * The value nanopb keeps for a field: its last occurrence, including across repeated occurrences
 * of the embedded message holding it, which nanopb merges where protobufjs keeps the last one.
 */
export declare const lastWireValue: (wire: WireScan, field: WireField) => Uint8Array | undefined;
export declare const wireVarintValue: (content: Uint8Array) => number | undefined;
export {};
//# sourceMappingURL=PayloadCheckerShared.d.ts.map