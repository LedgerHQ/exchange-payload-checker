import type { SwapNgPartnerPublicKey } from "./SwapSignature";
import { type PayloadCheckReport } from "./PayloadCheckerShared";
export type SellPayloadCheckInput = {
    /** base64url `NewSellResponse`, without the leading "." Ledger Live adds */
    payload: string;
    /** base64url of the 64-byte compact r||s signature */
    signature: string;
    partnerPublicKey: SwapNgPartnerPublicKey;
    /** values the payload must contain, only the provided keys are compared */
    expected?: {
        /** 32-byte hex nonce returned by `startNewTransaction`, case-insensitive, optional "0x" */
        deviceTransactionId?: string;
        inCurrency?: string;
        inAmount?: bigint;
        inAddress?: string;
        outCurrency?: string;
    };
};
/**
 * A decoded `NewSellResponse`, normalized for display.
 */
export type DecodedSellPayload = {
    traderEmail?: string;
    inCurrency: string;
    inAmount: bigint;
    inAddress: string;
    inExtraId?: string;
    outCurrency: string;
    /** decimal string of `out_amount`, e.g. "84.38", or "<coefficient>e-<exponent>" above 255 */
    outAmount: string;
    /** hex of `device_transaction_id` */
    deviceTransactionId?: string;
};
export type SellPayloadCheckReport = PayloadCheckReport<DecodedSellPayload>;
/**
 * Checks a Sell NG payload and its partner signature against the rules of Ledger Live and the
 * Exchange app, without a device, with the same issue codes as `checkSwapPayload`. Fee, address
 * ownership and coin app checks still happen on the device. Pure and synchronous, inputs are
 * never logged.
 */
export declare function checkSellPayload(input: SellPayloadCheckInput): SellPayloadCheckReport;
//# sourceMappingURL=SellPayloadChecker.d.ts.map