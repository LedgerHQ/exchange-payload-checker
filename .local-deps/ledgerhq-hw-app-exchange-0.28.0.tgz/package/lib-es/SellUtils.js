import { ledger_trade } from "./generate-protocol";
import { isHexadecimal } from "./shared-utils";
export async function decodeSellPayload(payload) {
    const buffer = isHexadecimal(payload)
        ? Buffer.from(payload, "hex")
        : Buffer.from(payload, "base64");
    const SellResponse = ledger_trade.NewSellResponse;
    const decodedPayload = SellResponse.decode(buffer);
    const err = SellResponse.verify(decodedPayload);
    if (err) {
        throw Error(err);
    }
    return {
        ...decodedPayload,
    };
}
//# sourceMappingURL=SellUtils.js.map